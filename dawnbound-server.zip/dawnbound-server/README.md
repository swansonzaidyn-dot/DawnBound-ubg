# Dawnbound Server

A self-hosted version of Dawnbound: real email/password accounts, a shared
SQLite database, and file uploads — one Node.js process, no third-party
backend service required.

## Run it locally

```
npm install
cp .env.example .env
```

Open `.env` and set `JWT_SECRET` (generate one with `openssl rand -hex 32`).
Leave the `SMTP_*` fields blank for now — without them, verification links
just print to the terminal instead of being emailed, which is fine for
trying things out.

```
npm start
```

Visit http://localhost:3000. Sign up, and watch the terminal for the
verification link (or check your inbox if you configured SMTP).

## How accounts work

- Passwords are hashed with bcrypt before they ever touch the database —
  the plaintext password is never stored.
- Signing in issues a JWT in an `httpOnly` cookie, so it can't be read by
  page JavaScript (including any game a user uploads).
- `/api/auth/signup` sends a real verification email via whatever SMTP
  provider you configure in `.env` (any provider works — Gmail app
  passwords, Resend, Postmark, SES, etc.). Until `SMTP_HOST` is set, links
  are logged to the server console instead, so you can develop without an
  email provider.
- Login is rate-limited (20 attempts / 15 min per IP) to slow down
  brute-forcing.

**Not included, worth adding if you go further:** a "forgot password" flow
(same shape as verification — generate a token, email a link, let them set
a new password) and gating certain actions on `emailVerified`.

## Data

Everything lives in `dawnbound.db`, a single SQLite file created on first
run (via `better-sqlite3`). Uploaded games are saved to `/uploads` on disk.
Back up both if you care about the data.

## Deploying

This is a normal Node app — it'll run on Render, Railway, Fly.io, a VPS,
etc. Two things matter more here than on a typical app:

1. **Persistent disk.** `dawnbound.db` and `/uploads` are plain files. Most
   free-tier PaaS plans wipe the filesystem on every deploy or restart —
   you need a plan/add-on with a persistent volume, or point `db.js` at a
   hosted database instead (swapping `better-sqlite3` for `pg` and a
   provider like Neon or Supabase isn't a large change, since the queries
   are plain SQL).
2. **HTTPS.** Set `NODE_ENV=production` so cookies are marked `secure`
   (browsers refuse to send `secure` cookies over plain HTTP). Any of the
   platforms above terminate HTTPS for you automatically.

Set `BASE_URL` in `.env` to your real domain once deployed — it's used to
build the link inside verification emails.

## Security notes

- Uploaded games run inside a sandboxed `<iframe sandbox="allow-scripts">`
  with no `allow-same-origin`, so an uploaded game can't read cookies, call
  your API as the logged-in user, or otherwise touch the rest of the site.
- There's no admin/moderation review of uploads before they go live — for
  anything beyond a hobby project with people you trust, you'll want a
  review step or at least a report button before opening uploads to the
  public.
