const path = require("path");
const Database = require("better-sqlite3");

const db = new Database(path.join(__dirname, "dawnbound.db"));
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  email_verified INTEGER NOT NULL DEFAULT 0,
  verify_token TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS games (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'arcade',
  description TEXT NOT NULL DEFAULT '',
  icon TEXT NOT NULL DEFAULT '🎮',
  is_custom INTEGER NOT NULL DEFAULT 0,
  uploader_id INTEGER REFERENCES users(id),
  file_path TEXT,
  builtin_key TEXT,
  plays INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS ratings (
  game_id INTEGER NOT NULL REFERENCES games(id),
  user_id INTEGER NOT NULL REFERENCES users(id),
  rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
  PRIMARY KEY (game_id, user_id)
);

CREATE TABLE IF NOT EXISTS favorites (
  user_id INTEGER NOT NULL REFERENCES users(id),
  game_id INTEGER NOT NULL REFERENCES games(id),
  PRIMARY KEY (user_id, game_id)
);

CREATE TABLE IF NOT EXISTS posts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  text TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
`);

// Seed the built-in demo games once.
const BUILTIN = [
  ["Neon Dash", "arcade", "A fast reflex challenge through a glowing obstacle course.", "⚡", "neon-dash"],
  ["Block Shift", "puzzle", "Move, match and clear blocks before the board fills up.", "▦", "block-shift"],
  ["Orbit Command", "strategy", "Plan your moves and control a tiny orbital system.", "◉", "orbit-command"],
  ["Sky Runner", "action", "Keep moving, dodge hazards and chase a high score.", "✦", "sky-runner"],
  ["Pixel Miner", "arcade", "Dig through a procedural pixel world and collect treasures.", "⛏", "pixel-miner"],
  ["Gridlock", "puzzle", "Solve increasingly tricky grid-based logic challenges.", "▤", "gridlock"],
];
const already = db.prepare("SELECT COUNT(*) c FROM games WHERE is_custom = 0").get().c;
if (already === 0) {
  const insert = db.prepare(
    "INSERT INTO games (title, category, description, icon, is_custom, builtin_key) VALUES (?,?,?,?,0,?)"
  );
  for (const g of BUILTIN) insert.run(...g);
}

module.exports = db;
