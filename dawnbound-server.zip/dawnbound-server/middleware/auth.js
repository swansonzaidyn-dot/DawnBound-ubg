const jwt = require("jsonwebtoken");

function readUser(req) {
  const token = req.cookies && req.cookies.token;
  if (!token) return null;
  try {
    return jwt.verify(token, process.env.JWT_SECRET);
  } catch (e) {
    return null;
  }
}

// Attaches req.user if a valid cookie is present; never blocks the request.
function optionalAuth(req, res, next) {
  req.user = readUser(req);
  next();
}

// Blocks the request with 401 if there's no valid session.
function requireAuth(req, res, next) {
  const user = readUser(req);
  if (!user) return res.status(401).json({ error: "sign_in_required" });
  req.user = user;
  next();
}

module.exports = { optionalAuth, requireAuth };
