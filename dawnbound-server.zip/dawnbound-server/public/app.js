const app = document.querySelector("#app");
const esc = (s) =>
  String(s).replace(/[&<>"']/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" }[m]));

let me = null; // {id,email,username,emailVerified} | null
let games = [];

async function api(path, opts = {}) {
  const res = await fetch("/api" + path, {
    credentials: "include",
    headers: opts.body instanceof FormData ? undefined : { "Content-Type": "application/json" },
    ...opts,
  });
  let data = null;
  try {
    data = await res.json();
  } catch (e) {}
  if (!res.ok) throw Object.assign(new Error((data && data.error) || "request_failed"), { data, status: res.status });
  return data;
}

async function loadMe() {
  const d = await api("/auth/me");
  me = d.user;
}
async function loadGames() {
  const d = await api("/games");
  games = d.games;
}

function shell(content) {
  app.innerHTML = `<div class="shell"><header class="top">
    <a class="logo" href="#/"><b>D</b>DAWNBOUND</a>
    <nav class="nav">
      <button data-route="/">Games</button>
      <button data-route="/favorites">Favorites</button>
      <button data-route="/community">Community</button>
      <button data-route="/upload">Upload</button>
      <button data-route="/stats">Stats</button>
    </nav>
    <div class="account">${
      me
        ? `<span class="muted">${esc(me.username)}${me.emailVerified ? "" : " · unverified"}</span><button class="btn" id="logoutBtn">Log out</button>`
        : `<button class="btn" id="loginBtn">Sign in</button><button class="btn primary" id="signupBtn">Sign up</button>`
    }</div>
  </header><main class="wrap">${content}</main>
  <footer><span>Dawnbound Arcade Terminal</span><span>Self-hosted · real accounts</span></footer></div>`;
  document.querySelectorAll("[data-route]").forEach((b) => (b.onclick = () => (location.hash = "#" + b.dataset.route)));
  document.querySelector("#loginBtn")?.addEventListener("click", () => authModal("login"));
  document.querySelector("#signupBtn")?.addEventListener("click", () => authModal("signup"));
  document.querySelector("#logoutBtn")?.addEventListener("click", async () => {
    await api("/auth/logout", { method: "POST" });
    me = null;
    route();
  });
}

function authModal(mode) {
  const isSignup = mode === "signup";
  document.body.insertAdjacentHTML(
    "beforeend",
    `<div class="modal" id="modal"><div class="modalbox">
      <h2>${isSignup ? "Create account" : "Sign in"}</h2>
      ${isSignup ? '<input id="aUsername" placeholder="Username (3-20 chars)">' : ""}
      <input id="aEmail" type="email" placeholder="Email">
      <input id="aPassword" type="password" placeholder="Password (8+ chars)">
      <div class="error" id="aError"></div>
      <div class="row" style="margin-top:8px">
        <button class="btn" id="aCancel">Cancel</button>
        <button class="btn primary" id="aSubmit">${isSignup ? "Sign up" : "Sign in"}</button>
      </div>
    </div></div>`
  );
  document.querySelector("#aCancel").onclick = () => document.querySelector("#modal").remove();
  document.querySelector("#aSubmit").onclick = async () => {
    const email = document.querySelector("#aEmail").value.trim();
    const password = document.querySelector("#aPassword").value;
    const errEl = document.querySelector("#aError");
    try {
      if (isSignup) {
        const username = document.querySelector("#aUsername").value.trim();
        const d = await api("/auth/signup", { method: "POST", body: JSON.stringify({ email, username, password }) });
        me = d.user;
        errEl.textContent = "";
        alert("Account created! Check the server console (or your inbox) for a verification link.");
      } else {
        const d = await api("/auth/login", { method: "POST", body: JSON.stringify({ email, password }) });
        me = d.user;
      }
      document.querySelector("#modal").remove();
      route();
    } catch (e) {
      errEl.textContent = (e.data && e.data.detail) || e.message.replace(/_/g, " ");
    }
  };
}

function home() {
  shell(`<div class="eyebrow">DAWNBOUND // ARCADE TERMINAL</div><h1 class="page-title">Featured games</h1>
    <div class="controls"><input id="q" placeholder="Search..."><select id="cat"><option value="all">All</option><option>arcade</option><option>puzzle</option><option>strategy</option><option>action</option></select></div>
    <div id="grid" class="grid"></div>`);
  renderGrid(games);
  document.querySelector("#q").oninput = filterGrid;
  document.querySelector("#cat").onchange = filterGrid;
}
function filterGrid() {
  const q = document.querySelector("#q").value.toLowerCase();
  const c = document.querySelector("#cat").value;
  renderGrid(games.filter((g) => (c === "all" || g.category === c) && (g.title.toLowerCase().includes(q) || g.description.toLowerCase().includes(q))));
}
function renderGrid(list) {
  const grid = document.querySelector("#grid");
  if (!grid) return;
  grid.innerHTML = list.length ? list.map(card).join("") : `<div class="notice">No games found.</div>`;
}
function card(g) {
  const r = Math.round(g.avgRating);
  return `<article class="card"><div class="cover">${g.icon}</div><div class="info"><h3>${esc(g.title)}</h3><p>${esc(g.description)}</p>
    <div class="meta"><span class="tag">${esc(g.category)} · ${g.plays} plays</span>
    <span class="row"><button class="btn" data-fav="${g.id}">${g.favorited ? "★" : "☆"}</button><a class="btn primary" href="#/game/${g.id}">Play</a></span></div>
    <div class="muted" style="margin-top:10px">Rating: <span class="star">${"★".repeat(r)}${"☆".repeat(5 - r)}</span> ${g.avgRating || ""}</div></div></article>`;
}

function favorites() {
  shell(`<div class="eyebrow">YOUR LIBRARY</div><h1 class="page-title">Favorites</h1>${me ? "" : '<div class="notice">Sign in to save favorites.</div>'}<div class="grid" id="grid"></div>`);
  renderGrid(games.filter((g) => g.favorited));
}

async function gamePage(id) {
  const g = games.find((x) => String(x.id) === String(id));
  if (!g) return shell(`<h1>Game not found</h1>`);
  try {
    const d = await api(`/games/${id}/play`, { method: "POST" });
    g.plays = d.plays;
  } catch (e) {}
  const r = Math.round(g.avgRating);
  shell(`<a class="muted" href="#/">← Back</a><div class="gamebox" style="margin-top:18px">
    <div class="gamehead"><div><div class="eyebrow">${esc(g.category)}</div><h2>${esc(g.title)}</h2></div>
    <button class="btn" data-fav="${g.id}">${g.favorited ? "★" : "☆"}</button></div>
    <iframe class="gameframe" sandbox="allow-scripts allow-pointer-lock" src="${g.fileUrl || "/demos/" + g.builtinKey + ".html"}"></iframe>
    <div class="info"><p class="muted">${esc(g.description)}</p>
    <div class="row">${[1, 2, 3, 4, 5].map((n) => `<button class="btn" data-rate="${n}" data-gid="${g.id}">${n <= g.myRating ? "★" : "☆"}</button>`).join("")}</div>
    <p class="muted" style="margin-top:8px">Average ${g.avgRating || 0} (${g.ratingCount} ratings) · ${g.plays} plays</p></div></div>`);
}

function community() {
  shell(`<div class="eyebrow">COMMUNITY</div><h1 class="page-title">Community</h1>
    <textarea id="postText" rows="2" placeholder="${me ? "Share something…" : "Sign in to post"}" ${me ? "" : "disabled"}></textarea>
    <button class="btn primary" id="postBtn" style="margin-top:8px">Post</button>
    <div id="posts" style="margin-top:20px"></div>`);
  document.querySelector("#postBtn").onclick = async () => {
    if (!me) return alert("Sign in to post.");
    const t = document.querySelector("#postText");
    const text = t.value.trim();
    if (!text) return;
    t.value = "";
    try {
      await api("/posts", { method: "POST", body: JSON.stringify({ text }) });
      loadPosts();
    } catch (e) {
      alert("Post failed.");
    }
  };
  loadPosts();
}
async function loadPosts() {
  const el = document.querySelector("#posts");
  if (!el) return;
  try {
    const d = await api("/posts");
    el.innerHTML = d.posts.length
      ? d.posts.map((p) => `<div class="post"><b>${esc(p.username)}</b><p>${esc(p.text)}</p></div>`).join("")
      : `<div class="notice">No posts yet — be the first!</div>`;
  } catch (e) {
    el.innerHTML = `<div class="notice">Couldn't load posts.</div>`;
  }
}

function uploadPage() {
  shell(`<div class="eyebrow">SUBMIT</div><h1 class="page-title">Upload a game</h1>
    ${me ? "" : '<div class="notice">Sign in to upload.</div>'}
    <div class="notice">Self-contained HTML5 games only — one .html file, no external assets.</div>
    <input id="uTitle" placeholder="Title" style="width:100%;margin-bottom:8px">
    <select id="uCat" style="margin-bottom:8px"><option>arcade</option><option>puzzle</option><option>strategy</option><option>action</option></select>
    <textarea id="uDesc" rows="3" placeholder="Short description"></textarea>
    <input id="uFile" type="file" accept=".html" style="margin-top:8px;display:block">
    <button class="btn primary" id="uBtn" style="margin-top:10px">Upload</button>`);
  document.querySelector("#uBtn").onclick = doUpload;
}
async function doUpload() {
  if (!me) return alert("Sign in to upload.");
  const title = document.querySelector("#uTitle").value.trim();
  const file = document.querySelector("#uFile").files[0];
  if (!title || !file) return alert("Add a title and choose an .html file.");
  const fd = new FormData();
  fd.append("title", title);
  fd.append("category", document.querySelector("#uCat").value);
  fd.append("description", document.querySelector("#uDesc").value.trim());
  fd.append("file", file);
  try {
    await api("/uploads", { method: "POST", body: fd });
    await loadGames();
    alert("Uploaded! Added to the library.");
    location.hash = "#/";
  } catch (e) {
    alert("Upload failed: " + ((e.data && e.data.detail) || e.message));
  }
}

async function statsPage() {
  shell(`<div class="eyebrow">CONTROL CENTER</div><h1 class="page-title">Platform stats</h1><div class="statgrid" id="statgrid"></div>`);
  const totalPlays = games.reduce((a, g) => a + g.plays, 0);
  const customCount = games.filter((g) => g.custom).length;
  document.querySelector("#statgrid").innerHTML = `<div class="stat">Games<b>${games.length}</b></div><div class="stat">Total plays<b>${totalPlays}</b></div><div class="stat">Community uploads<b>${customCount}</b></div>`;
}

document.addEventListener("click", async (e) => {
  const f = e.target.closest("[data-fav]");
  if (f) {
    if (!me) return alert("Sign in to save favorites.");
    const id = f.dataset.fav;
    const d = await api(`/games/${id}/favorite`, { method: "POST" });
    const g = games.find((x) => String(x.id) === id);
    if (g) g.favorited = d.favorited;
    route();
  }
  const r = e.target.closest("[data-rate]");
  if (r) {
    if (!me) return alert("Sign in to rate.");
    const id = r.dataset.gid;
    const d = await api(`/games/${id}/rate`, { method: "POST", body: JSON.stringify({ rating: +r.dataset.rate }) });
    const g = games.find((x) => String(x.id) === id);
    if (g) Object.assign(g, { avgRating: d.avgRating, ratingCount: d.ratingCount, myRating: d.myRating });
    route();
  }
});

function route() {
  const p = location.hash.replace(/^#/, "") || "/";
  if (p === "/" || p === "/games") home();
  else if (p === "/favorites") favorites();
  else if (p === "/community") community();
  else if (p === "/upload") uploadPage();
  else if (p === "/stats") statsPage();
  else if (p.startsWith("/game/")) gamePage(decodeURIComponent(p.split("/")[2]));
  else home();
}

window.addEventListener("hashchange", route);
(async function boot() {
  try {
    await loadMe();
    await loadGames();
  } catch (e) {
    console.error(e);
  }
  route();
})();
