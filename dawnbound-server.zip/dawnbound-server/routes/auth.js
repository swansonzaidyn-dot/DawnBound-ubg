const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");
const rateLimit = require("express-rate-limit");
const db = require("../db");
const { sendVerificationEmail } = require("../utils/mailer");
const { requireAuth, optionalAuth } = require("../middleware/auth");

const router = express.Router();

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 20,
  standardHeaders: true,
  legacyHeaders: false,
});

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const USERNAME_RE = /^[a-zA-Z0-9_]{3,20}$/;

function issueSession(res, user) {
  const token = jwt.sign(
    { id: user.id, email: user.email, username: user.username },
    process.env.JWT_SECRET,
    { expiresIn: "30d" }
  );
  res.cookie("token", token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 30 * 24 * 60 * 60 * 1000,
  });
}

router.post("/signup", authLimiter, async (req, res) => {
  const { email, username, password } = req.body || {};
  if (!email || !EMAIL_RE.test(email)) return res.status(400).json({ error: "invalid_email" });
  if (!username || !USERNAME_RE.test(username))
    return res.status(400).json({ error: "invalid_username", detail: "3-20 letters, numbers or _" });
  if (!password || password.length < 8)
    return res.status(400).json({ error: "weak_password", detail: "8+ characters" });

  const existing = db
    .prepare("SELECT id FROM users WHERE email = ? OR username = ?")
    .get(email.toLowerCase(), username);
  if (existing) return res.status(409).json({ error: "already_registered" });

  const passwordHash = await bcrypt.hash(password, 10);
  const verifyToken = crypto.randomBytes(24).toString("hex");

  const info = db
    .prepare(
      "INSERT INTO users (email, username, password_hash, verify_token) VALUES (?,?,?,?)"
    )
    .run(email.toLowerCase(), username, passwordHash, verifyToken);

  const user = { id: info.lastInsertRowid, email: email.toLowerCase(), username };
  issueSession(res, user);

  const link = `${process.env.BASE_URL || "http://localhost:3000"}/api/auth/verify/${verifyToken}`;
  sendVerificationEmail(user.email, link).catch((e) => console.error("email send failed:", e.message));

  res.json({ user: { ...user, emailVerified: false } });
});

router.post("/login", authLimiter, async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: "missing_fields" });

  const row = db.prepare("SELECT * FROM users WHERE email = ?").get(String(email).toLowerCase());
  if (!row) return res.status(401).json({ error: "invalid_credentials" });

  const ok = await bcrypt.compare(password, row.password_hash);
  if (!ok) return res.status(401).json({ error: "invalid_credentials" });

  issueSession(res, row);
  res.json({
    user: { id: row.id, email: row.email, username: row.username, emailVerified: !!row.email_verified },
  });
});

router.post("/logout", (req, res) => {
  res.clearCookie("token");
  res.json({ ok: true });
});

router.get("/verify/:token", (req, res) => {
  const row = db.prepare("SELECT id FROM users WHERE verify_token = ?").get(req.params.token);
  if (!row) return res.status(400).send("Invalid or expired verification link.");
  db.prepare("UPDATE users SET email_verified = 1, verify_token = NULL WHERE id = ?").run(row.id);
  res.send("Email verified — you can close this tab and go back to Dawnbound.");
});

router.get("/me", optionalAuth, (req, res) => {
  if (!req.user) return res.json({ user: null });
  const row = db.prepare("SELECT id, email, username, email_verified FROM users WHERE id = ?").get(req.user.id);
  if (!row) return res.json({ user: null });
  res.json({ user: { id: row.id, email: row.email, username: row.username, emailVerified: !!row.email_verified } });
});

module.exports = router;
