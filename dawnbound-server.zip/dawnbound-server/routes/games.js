const express = require("express");
const db = require("../db");
const { requireAuth, optionalAuth } = require("../middleware/auth");

const router = express.Router();

function withStats(gameRow, userId) {
  const agg = db
    .prepare("SELECT AVG(rating) avg, COUNT(*) n FROM ratings WHERE game_id = ?")
    .get(gameRow.id);
  const mine = userId
    ? db.prepare("SELECT rating FROM ratings WHERE game_id = ? AND user_id = ?").get(gameRow.id, userId)
    : null;
  const fav = userId
    ? db.prepare("SELECT 1 FROM favorites WHERE game_id = ? AND user_id = ?").get(gameRow.id, userId)
    : null;
  return {
    id: gameRow.id,
    title: gameRow.title,
    category: gameRow.category,
    description: gameRow.description,
    icon: gameRow.icon,
    custom: !!gameRow.is_custom,
    plays: gameRow.plays,
    avgRating: agg.n ? Math.round((agg.avg + Number.EPSILON) * 10) / 10 : 0,
    ratingCount: agg.n,
    myRating: mine ? mine.rating : 0,
    favorited: !!fav,
    // For built-in games the frontend renders a bundled demo by builtin_key.
    // For uploads it plays the uploaded file directly.
    builtinKey: gameRow.builtin_key,
    fileUrl: gameRow.file_path ? `/uploads/${gameRow.file_path}` : null,
  };
}

router.get("/", optionalAuth, (req, res) => {
  const rows = db.prepare("SELECT * FROM games ORDER BY created_at DESC").all();
  res.json({ games: rows.map((r) => withStats(r, req.user && req.user.id)) });
});

router.post("/:id/play", (req, res) => {
  const id = Number(req.params.id);
  const result = db.prepare("UPDATE games SET plays = plays + 1 WHERE id = ?").run(id);
  if (result.changes === 0) return res.status(404).json({ error: "not_found" });
  const row = db.prepare("SELECT plays FROM games WHERE id = ?").get(id);
  res.json({ plays: row.plays });
});

router.post("/:id/rate", requireAuth, (req, res) => {
  const id = Number(req.params.id);
  const rating = Number((req.body || {}).rating);
  if (!Number.isInteger(rating) || rating < 1 || rating > 5)
    return res.status(400).json({ error: "invalid_rating" });
  const game = db.prepare("SELECT id FROM games WHERE id = ?").get(id);
  if (!game) return res.status(404).json({ error: "not_found" });

  db.prepare(
    `INSERT INTO ratings (game_id, user_id, rating) VALUES (?,?,?)
     ON CONFLICT(game_id, user_id) DO UPDATE SET rating = excluded.rating`
  ).run(id, req.user.id, rating);

  const agg = db.prepare("SELECT AVG(rating) avg, COUNT(*) n FROM ratings WHERE game_id = ?").get(id);
  res.json({ avgRating: Math.round((agg.avg + Number.EPSILON) * 10) / 10, ratingCount: agg.n, myRating: rating });
});

router.post("/:id/favorite", requireAuth, (req, res) => {
  const id = Number(req.params.id);
  const existing = db
    .prepare("SELECT 1 FROM favorites WHERE game_id = ? AND user_id = ?")
    .get(id, req.user.id);
  if (existing) {
    db.prepare("DELETE FROM favorites WHERE game_id = ? AND user_id = ?").run(id, req.user.id);
    return res.json({ favorited: false });
  }
  db.prepare("INSERT INTO favorites (game_id, user_id) VALUES (?,?)").run(id, req.user.id);
  res.json({ favorited: true });
});

module.exports = router;
