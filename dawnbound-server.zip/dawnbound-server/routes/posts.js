const express = require("express");
const db = require("../db");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();

router.get("/", (req, res) => {
  const rows = db
    .prepare(
      `SELECT posts.id, posts.text, posts.created_at, users.username
       FROM posts JOIN users ON users.id = posts.user_id
       ORDER BY posts.created_at DESC LIMIT 50`
    )
    .all();
  res.json({ posts: rows });
});

router.post("/", requireAuth, (req, res) => {
  const text = String((req.body || {}).text || "").trim();
  if (!text) return res.status(400).json({ error: "empty_post" });
  if (text.length > 500) return res.status(400).json({ error: "too_long" });
  db.prepare("INSERT INTO posts (user_id, text) VALUES (?,?)").run(req.user.id, text);
  res.json({ ok: true });
});

module.exports = router;
