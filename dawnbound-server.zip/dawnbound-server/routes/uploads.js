const express = require("express");
const multer = require("multer");
const path = require("path");
const crypto = require("crypto");
const db = require("../db");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();

const storage = multer.diskStorage({
  destination: path.join(__dirname, "..", "uploads"),
  filename: (req, file, cb) => cb(null, crypto.randomBytes(16).toString("hex") + ".html"),
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5 MB
  fileFilter: (req, file, cb) => {
    const okExt = path.extname(file.originalname).toLowerCase() === ".html";
    const okType = ["text/html", "application/octet-stream", "text/plain"].includes(file.mimetype);
    cb(null, okExt && okType);
  },
});

router.post("/", requireAuth, upload.single("file"), (req, res) => {
  if (!req.file) return res.status(400).json({ error: "invalid_file", detail: "Choose a .html file" });
  const title = String((req.body || {}).title || "").trim().slice(0, 80);
  const category = String((req.body || {}).category || "arcade").trim().slice(0, 20);
  const description = String((req.body || {}).description || "Community upload").trim().slice(0, 300);
  if (!title) return res.status(400).json({ error: "missing_title" });

  const info = db
    .prepare(
      "INSERT INTO games (title, category, description, icon, is_custom, uploader_id, file_path) VALUES (?,?,?,?,1,?,?)"
    )
    .run(title, category, description, "🎮", req.user.id, req.file.filename);

  res.json({ id: info.lastInsertRowid, fileUrl: `/uploads/${req.file.filename}` });
});

module.exports = router;
