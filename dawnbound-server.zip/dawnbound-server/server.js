require("dotenv").config();
const path = require("path");
const express = require("express");
const cookieParser = require("cookie-parser");

if (!process.env.JWT_SECRET) {
  console.error("Missing JWT_SECRET in .env — generate one with: openssl rand -hex 32");
  process.exit(1);
}

const app = express();
app.set("trust proxy", 1); // needed on most PaaS so secure cookies work behind their proxy

app.use(express.json());
app.use(cookieParser());

// Minimal hardening headers.
app.use((req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "SAMEORIGIN");
  next();
});

app.use("/api/auth", require("./routes/auth"));
app.use("/api/games", require("./routes/games"));
app.use("/api/posts", require("./routes/posts"));
app.use("/api/uploads", require("./routes/uploads"));

// Uploaded games and bundled demos are only ever loaded inside a sandboxed
// <iframe> by the frontend — see the `sandbox` attribute in public/app.js.
app.use("/uploads", express.static(path.join(__dirname, "uploads")));
app.use(express.static(path.join(__dirname, "public")));

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Dawnbound running on http://localhost:${port}`));
