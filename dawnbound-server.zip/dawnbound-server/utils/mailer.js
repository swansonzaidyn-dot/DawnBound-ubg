const nodemailer = require("nodemailer");

const configured = !!(process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS);

const transporter = configured
  ? nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT || 587),
      secure: Number(process.env.SMTP_PORT) === 465,
      auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
    })
  : null;

async function sendVerificationEmail(to, link) {
  if (!transporter) {
    // No SMTP configured — fine for local dev. The link still works.
    console.log(`\n[dev] Verification link for ${to}:\n  ${link}\n`);
    return;
  }
  await transporter.sendMail({
    from: process.env.EMAIL_FROM || "Dawnbound <no-reply@example.com>",
    to,
    subject: "Verify your Dawnbound account",
    text: `Welcome to Dawnbound! Verify your email: ${link}`,
    html: `<p>Welcome to Dawnbound!</p><p><a href="${link}">Click here to verify your email</a></p>`,
  });
}

module.exports = { sendVerificationEmail };
